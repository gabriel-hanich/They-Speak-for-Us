exports = async function(arg){
  const mongoClient = context.services.get("mongodb-atlas");
  const vaderSentiment = require("vader-sentiment");
  const Parser = require("rss-parser");
  const dbName = "News-Data"
  
  const rssParser = new Parser();
  // Get list of all media outlets
  outletList = await mongoClient.db(dbName).collection("outletsList").find();
  outletsList = await outletList.toArray();
  
  // Read which outlet needs to be scraped
  var runCount = await mongoClient.db(dbName).collection("backend-data").find();
  runCount = await runCount.toArray();
  runCount = runCount[0]["runCount"]
  const scrapeIndex = runCount % (outletsList.length)
  
  // Increment the runcount by Int16Array
  await mongoClient.db(dbName).collection("backend-data").updateOne(
    { runCount: runCount },
    {
      $set: { runCount: runCount + 1}
    }
  );
  
  
  scrapeOutlet = outletsList[scrapeIndex]["outletName"]
  scrapeURL = outletsList[scrapeIndex]["RSSLink"]
  console.log("Scraping from " + scrapeOutlet)
  
  // Get all the articles from every media outlet
  articleList = []
  var articleCount = 0
  let rawArticleList = await rssParser.parseURL(scrapeURL);
  for(var articleIndex in rawArticleList["items"]){
    var sentimentScore = vaderSentiment.SentimentIntensityAnalyzer.polarity_scores(rawArticleList["items"][articleIndex]["title"])["compound"];
    articleList.push({
      "outletName": scrapeOutlet,
      "headline": rawArticleList["items"][articleIndex]["title"],
      "description": rawArticleList["items"][articleIndex]["content"],
      "author": rawArticleList["items"][articleIndex]["creator"],
      "publishDate": new Date(rawArticleList["items"][articleIndex]["isoDate"]),
      "isLegacy": false,
      "sentimentScore": sentimentScore,
      "linkToArticle": rawArticleList["items"][articleIndex]["link"],
      "catergories": rawArticleList["items"][articleIndex]["categories"],
    });
    articleCount += 1;
  }
  
  console.log(`Total articles counted = ${articleCount}`);
  console.log("Beginning to upload articles");
  
  // Save every article that ins't already in the DB
  var uploadCount = 0;
  const articleCollection = await mongoClient.db(dbName).collection("newsData");
  var articleObj;
  for(var k=0; k<articleList.length; k++){
    articleObj = await articleCollection.find({
      outletName: { $exists: true, $eq: scrapeOutlet },
      headline:{ $exists: true, $eq: articleList[k]["headline"]}});
    articleObj = await articleObj.toArray();
    if (articleObj.length == 0){ // Check to see if any articles exists with the same headline and outlet
      await articleCollection.insertOne(articleList[k]); // If article is unique, upload it to the db
      uploadCount += 1
    }
  }
  console.log(`Finished Uploading ${uploadCount} articles, have a great day`)

  return {}
};