// This function is the endpoint's request handler.
exports = async function({ query, headers, body}, response) {
  const mongoDB = context.services.get("mongodb-atlas");
    
 let seriesDocuments = await mongoDB.db("News-Data").collection("outletsList").aggregate([
    {
      '$project': {
        'outletName': 1
      }
    }
  ]);
  
  let outletList = [];
  outletList = await seriesDocuments.toArray();
   
  return outletList;
};
