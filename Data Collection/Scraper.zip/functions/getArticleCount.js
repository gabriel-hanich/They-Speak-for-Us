// This function is the endpoint's request handler.
exports = async function({ query, headers, body}, response) {
  const mongoDB = context.services.get("mongodb-atlas");
    
  let articleCount = await mongoDB.db("News-Data").collection("newsData").count();
  let  outletCount = await mongoDB.db("News-Data").collection("outletsList").count();
  return {"articles": articleCount, "outlets": outletCount};
};
