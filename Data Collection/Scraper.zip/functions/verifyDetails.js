exports = async function(request){
  const mongoDB = context.services.get("mongodb-atlas");
  const body = JSON.parse(request.body.text());
  
  let docs = await mongoDB.db("user").collection("accounts").aggregate([
    {
        '$match': {
            'username': body['username'], 
            'pin': body['pin']
        }
    }
  ])
  
  docs = await docs.toArray();
  
  return docs.length >= 1;
}