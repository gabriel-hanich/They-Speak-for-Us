// This function is the endpoint's request handler.
exports = async function(request) {
    const mongoDB = context.services.get("mongodb-atlas");
    const crypto = require('crypto');
    const body = JSON.parse(request.body.text());
    const email = body["email"];
    const password = body["password"];
    
    const key = "Ph6Ga6VYPSEkVev73ZABtB6W"  

   res = {status: 200, success: true, userKey: ""};
   const encryptedPassword = await utils.crypto.encrypt("aes",  password.toString(), key);
   const decryptedPassword = await utils.crypto.decrypt("aes", encryptedPassword, key);
   const hashedPwd = await utils.crypto.hash("sha256", decryptedPassword);
   
   let accountDocs = await mongoDB.db("user").collection("accounts").aggregate([{'$match': {'email': email}}, {'$match': {'password': hashedPwd.toBase64()}}]);
   accountDocs = await accountDocs.toArray();
   if(accountDocs[0]){
     res["userKey"] = accountDocs[0]["pin"]
   }else{
     res["success"] = false
     res["status"] = 403;
   }
   return res
};
