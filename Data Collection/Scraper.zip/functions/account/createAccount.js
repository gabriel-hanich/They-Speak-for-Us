// This function is the endpoint's request handler.
exports = async function(request) {
    const mongoDB = context.services.get("mongodb-atlas");
    const crypto = require('crypto');
    const body = JSON.parse(request.body.text());
    const email = body["email"];
    const access = body["access"];
    const password = body["password"];
    
    const key = "Ph6Ga6VYPSEkVev73ZABtB6W"  
    
    let res = {"status": 200, "created": true, userPin: ""};
    
    // Ensure pin is valid 
    let pinDocs = await mongoDB.db("user").collection("accessPins").aggregate([{'$match': {'pin': access}}, {'$count': 'id'}]);
    pinDocs = await pinDocs.toArray();
    
    if(!pinDocs[0] | !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))){
      res["status"] = 401;
      res["created"] = false;
      return  res;
    }
    
    // Ensure email doesn't already exist
    let emailDocs = await mongoDB.db("user").collection("accounts").aggregate([{'$match': {'email': email}}, {'$count': 'id'}]);
    emailDocs = await emailDocs.toArray();
    if(emailDocs[0]){
      res["status"] = 203;
      res["created"] = false;
      return  res;
    }
    
    // Encrypt the password using the pwdKey (to be stored with the user)
    const encryptedPassword = await utils.crypto.encrypt("aes",  password.toString(), key);
    const decryptedPassword = await utils.crypto.decrypt("aes", encryptedPassword, key);
    const  hashedPwd = await utils.crypto.hash("sha256", decryptedPassword);
    const userPin = crypto.randomBytes(10).toString('hex');
    
    // Create user account
    const userData = {
      email: email,
      pin: userPin,
      accessPin: access,
      password: await hashedPwd.toBase64()
    }
    
    await mongoDB.db("user").collection("accounts").insertOne(userData);
    
    res["userPin"] = userPin
    
    return  res;
};
