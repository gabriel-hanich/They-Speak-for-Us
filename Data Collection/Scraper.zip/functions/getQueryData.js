exports = async function(request){
  const mongoDB = context.services.get("mongodb-atlas");
  const body = JSON.parse(request.body.text());
  
  // Verify user credentials
  let accountDocs = await mongoDB.db("user").collection("accounts").aggregate([{'$match': {'pin': body["pin"]}}]);
  accountDocs = await accountDocs.toArray();
  if(accountDocs.length == 0){
    return  {"status": 403,"sucess": false}
  }
  
  
  // Get a list of the dates
  let dateList = [];
  let startDate = new Date(body["startDate"]);
  let endDate = new Date(body["endDate"]);
  
  let date = new Date(body["startDate"]);
  date.setHours(0, 0, 0)
  while(date <= endDate){
    dateList.push(new Date(date));
    date.setDate(date.getDate() + 1);
  }
  
  let returnData = [];
  let aggregatePipeline = [];
  var dataPoints = {};
  for(var i=0; i<body["seriesList"].length; i++){
    let series = body["seriesList"][i];
     aggregatePipeline =[
      {
        '$match': {
          'publishDate': {
            '$gt': startDate, 
            '$lt': endDate
          }
        }
      }
    ];

    if(series["outlet"][0] != ['all']){ // If user requested specific outlet
      let outletRegex = "";
      series["outlet"].forEach((outletName, j=0)=>{
        if(j != 0){
          outletRegex += "|" + outletName
        }else{
          outletRegex += outletName
        }
        j += 1;
      })
      aggregatePipeline[0]["$match"]["outletName"] = {"$regex": outletRegex}
    }
    if(series["keywordList"].length !=0){ // If specific keywords are requested
      let keywordStr = "(?i)";
      series.keywordList.forEach((keyword, j=0) =>{ // Convert list of keywords to regex-compatible string
        if(j != 0){
          keywordStr += "|" + keyword;
        }else{
          keywordStr += keyword;
        }
      });
      aggregatePipeline[0]["$match"]["headline"] = {"$regex": keywordStr}
    }
    let seriesDocuments = await mongoDB.db("News-Data").collection("newsData").aggregate(aggregatePipeline);
    seriesDocuments = await seriesDocuments.toArray();
    
    let seriesData = {};
    if(body["plotType"] === "count"){
      dateList.forEach((date)=> seriesData[date] = 0);
      seriesDocuments.forEach((doc)=>{
        let seriesDate = doc.publishDate;
        seriesDate.setHours(0, 0, 0);
        seriesData[seriesDate] += 1;
      });
    }else if(body["plotType"] === "sentiment"){
      let sentimentData = {};
      dateList.forEach((date)=> {sentimentData[date] = {"count": 0, "score": 0}});
      seriesDocuments.forEach((doc)=>{
        let seriesDate = doc.publishDate;
        seriesDate.setHours(0, 0, 0);
        sentimentData[seriesDate]["count"] += 1;
        sentimentData[seriesDate]["score"] += doc.sentimentScore;
      });
      dateList.forEach((date)=>{
        let score = sentimentData[date];
        if(score["count"] === 0 || score["score"] === 0){
          seriesData[date] = 0
        }else{
          seriesData[date] = score["score"] / score["count"];
        }
      })
    }
    dataPoints[series['name']] = seriesData
  }

  return {"sucess": true, "data": dataPoints}
}